﻿namespace Client_programm
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.createDataBase_button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.endFFTtextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.beginFFTtextBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.buildFFTbtn = new System.Windows.Forms.Button();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.endRangeTextBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.beginRangeTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.buildGraph_btn = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.ch_45 = new System.Windows.Forms.Button();
            this.ch_48 = new System.Windows.Forms.Button();
            this.ch_47 = new System.Windows.Forms.Button();
            this.ch_46 = new System.Windows.Forms.Button();
            this.ch_44 = new System.Windows.Forms.Button();
            this.ch_43 = new System.Windows.Forms.Button();
            this.ch_42 = new System.Windows.Forms.Button();
            this.ch_41 = new System.Windows.Forms.Button();
            this.ch_40 = new System.Windows.Forms.Button();
            this.ch_39 = new System.Windows.Forms.Button();
            this.ch_38 = new System.Windows.Forms.Button();
            this.ch_37 = new System.Windows.Forms.Button();
            this.ch_36 = new System.Windows.Forms.Button();
            this.ch_35 = new System.Windows.Forms.Button();
            this.ch_34 = new System.Windows.Forms.Button();
            this.ch_33 = new System.Windows.Forms.Button();
            this.ch_32 = new System.Windows.Forms.Button();
            this.ch_31 = new System.Windows.Forms.Button();
            this.ch_30 = new System.Windows.Forms.Button();
            this.ch_29 = new System.Windows.Forms.Button();
            this.ch_28 = new System.Windows.Forms.Button();
            this.ch_27 = new System.Windows.Forms.Button();
            this.ch_26 = new System.Windows.Forms.Button();
            this.ch_25 = new System.Windows.Forms.Button();
            this.ch_24 = new System.Windows.Forms.Button();
            this.ch_23 = new System.Windows.Forms.Button();
            this.ch_22 = new System.Windows.Forms.Button();
            this.ch_21 = new System.Windows.Forms.Button();
            this.ch_20 = new System.Windows.Forms.Button();
            this.ch_19 = new System.Windows.Forms.Button();
            this.ch_18 = new System.Windows.Forms.Button();
            this.ch_17 = new System.Windows.Forms.Button();
            this.ch_16 = new System.Windows.Forms.Button();
            this.ch_15 = new System.Windows.Forms.Button();
            this.ch_14 = new System.Windows.Forms.Button();
            this.ch_13 = new System.Windows.Forms.Button();
            this.ch_12 = new System.Windows.Forms.Button();
            this.ch_11 = new System.Windows.Forms.Button();
            this.ch_7 = new System.Windows.Forms.Button();
            this.ch_10 = new System.Windows.Forms.Button();
            this.ch_9 = new System.Windows.Forms.Button();
            this.ch_8 = new System.Windows.Forms.Button();
            this.ch_6 = new System.Windows.Forms.Button();
            this.ch_5 = new System.Windows.Forms.Button();
            this.ch_4 = new System.Windows.Forms.Button();
            this.ch_3 = new System.Windows.Forms.Button();
            this.ch_2 = new System.Windows.Forms.Button();
            this.ch_1 = new System.Windows.Forms.Button();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.DataBaseName = new System.Windows.Forms.ComboBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // createDataBase_button
            // 
            this.createDataBase_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.createDataBase_button.Location = new System.Drawing.Point(22, 24);
            this.createDataBase_button.Name = "createDataBase_button";
            this.createDataBase_button.Size = new System.Drawing.Size(263, 35);
            this.createDataBase_button.TabIndex = 0;
            this.createDataBase_button.Text = "Создание БД/ загрузка данных";
            this.createDataBase_button.UseVisualStyleBackColor = true;
            this.createDataBase_button.Click += new System.EventHandler(this.createDataBase_button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label2.Location = new System.Drawing.Point(310, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(133, 18);
            this.label2.TabIndex = 3;
            this.label2.Text = "Имя базы данных";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.tabControl1.Location = new System.Drawing.Point(1, 89);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(845, 703);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.endFFTtextBox);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.beginFFTtextBox);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.buildFFTbtn);
            this.tabPage1.Controls.Add(this.chart2);
            this.tabPage1.Controls.Add(this.endRangeTextBox);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.beginRangeTextBox);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.buildGraph_btn);
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.panel2);
            this.tabPage1.Location = new System.Drawing.Point(4, 26);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(837, 673);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Анализ отдельных сигналов";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label11.Location = new System.Drawing.Point(583, 646);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(25, 18);
            this.label11.TabIndex = 18;
            this.label11.Text = "Гц";
            // 
            // endFFTtextBox
            // 
            this.endFFTtextBox.Location = new System.Drawing.Point(468, 643);
            this.endFFTtextBox.Name = "endFFTtextBox";
            this.endFFTtextBox.Size = new System.Drawing.Size(100, 23);
            this.endFFTtextBox.TabIndex = 17;
            this.endFFTtextBox.Text = "50000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label7.Location = new System.Drawing.Point(389, 646);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 18);
            this.label7.TabIndex = 16;
            this.label7.Text = "конец";
            // 
            // beginFFTtextBox
            // 
            this.beginFFTtextBox.Location = new System.Drawing.Point(246, 643);
            this.beginFFTtextBox.Name = "beginFFTtextBox";
            this.beginFFTtextBox.Size = new System.Drawing.Size(100, 23);
            this.beginFFTtextBox.TabIndex = 15;
            this.beginFFTtextBox.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label8.Location = new System.Drawing.Point(167, 646);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "начало";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label9.Location = new System.Drawing.Point(9, 646);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(143, 18);
            this.label9.TabIndex = 13;
            this.label9.Text = "Выбрать диапазон:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label10.Location = new System.Drawing.Point(300, 429);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(205, 18);
            this.label10.TabIndex = 12;
            this.label10.Text = "Спектр выбранного сигнала";
            // 
            // buildFFTbtn
            // 
            this.buildFFTbtn.Location = new System.Drawing.Point(686, 418);
            this.buildFFTbtn.Name = "buildFFTbtn";
            this.buildFFTbtn.Size = new System.Drawing.Size(122, 29);
            this.buildFFTbtn.TabIndex = 11;
            this.buildFFTbtn.Text = "Построить";
            this.buildFFTbtn.UseVisualStyleBackColor = true;
            this.buildFFTbtn.Click += new System.EventHandler(this.buildFFTbtn_Click);
            // 
            // chart2
            // 
            chartArea1.AxisX.MajorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea1.AxisX.Minimum = 0D;
            chartArea1.AxisX.MinorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea1.AxisX.ScaleView.MinSize = 0D;
            chartArea1.AxisX2.Minimum = 0D;
            chartArea1.AxisX2.ScaleView.MinSize = 0D;
            chartArea1.AxisY.MajorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea1.AxisY.Maximum = 2000D;
            chartArea1.AxisY.MinorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea1.AxisY2.Maximum = 2000D;
            chartArea1.BorderColor = System.Drawing.Color.LightGray;
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Alignment = System.Drawing.StringAlignment.Center;
            legend1.Enabled = false;
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(12, 453);
            this.chart2.Name = "chart2";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(796, 179);
            this.chart2.SuppressExceptions = true;
            this.chart2.TabIndex = 10;
            this.chart2.Text = "chart2";
            // 
            // endRangeTextBox
            // 
            this.endRangeTextBox.Location = new System.Drawing.Point(473, 391);
            this.endRangeTextBox.Name = "endRangeTextBox";
            this.endRangeTextBox.Size = new System.Drawing.Size(100, 23);
            this.endRangeTextBox.TabIndex = 9;
            this.endRangeTextBox.Text = "1500";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label6.Location = new System.Drawing.Point(394, 394);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 18);
            this.label6.TabIndex = 8;
            this.label6.Text = "конец";
            // 
            // beginRangeTextBox
            // 
            this.beginRangeTextBox.Location = new System.Drawing.Point(251, 391);
            this.beginRangeTextBox.Name = "beginRangeTextBox";
            this.beginRangeTextBox.Size = new System.Drawing.Size(100, 23);
            this.beginRangeTextBox.TabIndex = 7;
            this.beginRangeTextBox.Text = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label5.Location = new System.Drawing.Point(172, 394);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 18);
            this.label5.TabIndex = 6;
            this.label5.Text = "начало";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label4.Location = new System.Drawing.Point(14, 394);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(143, 18);
            this.label4.TabIndex = 5;
            this.label4.Text = "Выбрать диапазон:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label3.Location = new System.Drawing.Point(305, 177);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(209, 18);
            this.label3.TabIndex = 4;
            this.label3.Text = "График выбранного сигнала";
            // 
            // buildGraph_btn
            // 
            this.buildGraph_btn.Location = new System.Drawing.Point(691, 166);
            this.buildGraph_btn.Name = "buildGraph_btn";
            this.buildGraph_btn.Size = new System.Drawing.Size(122, 29);
            this.buildGraph_btn.TabIndex = 3;
            this.buildGraph_btn.Text = "Построить";
            this.buildGraph_btn.UseVisualStyleBackColor = true;
            this.buildGraph_btn.Click += new System.EventHandler(this.buildGraph_btn_Click);
            // 
            // chart1
            // 
            chartArea2.AxisX.MajorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea2.AxisX.Minimum = 0D;
            chartArea2.AxisX.MinorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea2.AxisX.ScaleView.MinSize = 0D;
            chartArea2.AxisX2.Minimum = 0D;
            chartArea2.AxisX2.ScaleView.MinSize = 0D;
            chartArea2.AxisY.MajorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea2.AxisY.MinorGrid.LineColor = System.Drawing.Color.Silver;
            chartArea2.BorderColor = System.Drawing.Color.LightGray;
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Alignment = System.Drawing.StringAlignment.Center;
            legend2.Enabled = false;
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(17, 201);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(796, 179);
            this.chart1.SuppressExceptions = true;
            this.chart1.TabIndex = 2;
            this.chart1.Text = "chart1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.label1.Location = new System.Drawing.Point(165, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 18);
            this.label1.TabIndex = 1;
            this.label1.Text = "Элементы антенны";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.ch_45);
            this.panel2.Controls.Add(this.ch_48);
            this.panel2.Controls.Add(this.ch_47);
            this.panel2.Controls.Add(this.ch_46);
            this.panel2.Controls.Add(this.ch_44);
            this.panel2.Controls.Add(this.ch_43);
            this.panel2.Controls.Add(this.ch_42);
            this.panel2.Controls.Add(this.ch_41);
            this.panel2.Controls.Add(this.ch_40);
            this.panel2.Controls.Add(this.ch_39);
            this.panel2.Controls.Add(this.ch_38);
            this.panel2.Controls.Add(this.ch_37);
            this.panel2.Controls.Add(this.ch_36);
            this.panel2.Controls.Add(this.ch_35);
            this.panel2.Controls.Add(this.ch_34);
            this.panel2.Controls.Add(this.ch_33);
            this.panel2.Controls.Add(this.ch_32);
            this.panel2.Controls.Add(this.ch_31);
            this.panel2.Controls.Add(this.ch_30);
            this.panel2.Controls.Add(this.ch_29);
            this.panel2.Controls.Add(this.ch_28);
            this.panel2.Controls.Add(this.ch_27);
            this.panel2.Controls.Add(this.ch_26);
            this.panel2.Controls.Add(this.ch_25);
            this.panel2.Controls.Add(this.ch_24);
            this.panel2.Controls.Add(this.ch_23);
            this.panel2.Controls.Add(this.ch_22);
            this.panel2.Controls.Add(this.ch_21);
            this.panel2.Controls.Add(this.ch_20);
            this.panel2.Controls.Add(this.ch_19);
            this.panel2.Controls.Add(this.ch_18);
            this.panel2.Controls.Add(this.ch_17);
            this.panel2.Controls.Add(this.ch_16);
            this.panel2.Controls.Add(this.ch_15);
            this.panel2.Controls.Add(this.ch_14);
            this.panel2.Controls.Add(this.ch_13);
            this.panel2.Controls.Add(this.ch_12);
            this.panel2.Controls.Add(this.ch_11);
            this.panel2.Controls.Add(this.ch_7);
            this.panel2.Controls.Add(this.ch_10);
            this.panel2.Controls.Add(this.ch_9);
            this.panel2.Controls.Add(this.ch_8);
            this.panel2.Controls.Add(this.ch_6);
            this.panel2.Controls.Add(this.ch_5);
            this.panel2.Controls.Add(this.ch_4);
            this.panel2.Controls.Add(this.ch_3);
            this.panel2.Controls.Add(this.ch_2);
            this.panel2.Controls.Add(this.ch_1);
            this.panel2.Location = new System.Drawing.Point(12, 28);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(462, 137);
            this.panel2.TabIndex = 0;
            // 
            // ch_45
            // 
            this.ch_45.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_45.Location = new System.Drawing.Point(270, 95);
            this.ch_45.Name = "ch_45";
            this.ch_45.Size = new System.Drawing.Size(35, 35);
            this.ch_45.TabIndex = 48;
            this.ch_45.Text = "45";
            this.ch_45.UseVisualStyleBackColor = false;
            this.ch_45.Click += new System.EventHandler(this.ch_45_Click);
            // 
            // ch_48
            // 
            this.ch_48.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_48.Location = new System.Drawing.Point(400, 95);
            this.ch_48.Name = "ch_48";
            this.ch_48.Size = new System.Drawing.Size(35, 35);
            this.ch_48.TabIndex = 47;
            this.ch_48.Text = "48";
            this.ch_48.UseVisualStyleBackColor = false;
            this.ch_48.Click += new System.EventHandler(this.ch_48_Click);
            // 
            // ch_47
            // 
            this.ch_47.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_47.Location = new System.Drawing.Point(368, 95);
            this.ch_47.Name = "ch_47";
            this.ch_47.Size = new System.Drawing.Size(35, 35);
            this.ch_47.TabIndex = 46;
            this.ch_47.Text = "47";
            this.ch_47.UseVisualStyleBackColor = false;
            this.ch_47.Click += new System.EventHandler(this.ch_47_Click);
            // 
            // ch_46
            // 
            this.ch_46.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_46.Location = new System.Drawing.Point(334, 95);
            this.ch_46.Name = "ch_46";
            this.ch_46.Size = new System.Drawing.Size(35, 35);
            this.ch_46.TabIndex = 45;
            this.ch_46.Text = "46";
            this.ch_46.UseVisualStyleBackColor = false;
            this.ch_46.Click += new System.EventHandler(this.ch_46_Click);
            // 
            // ch_44
            // 
            this.ch_44.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_44.Location = new System.Drawing.Point(239, 95);
            this.ch_44.Name = "ch_44";
            this.ch_44.Size = new System.Drawing.Size(35, 35);
            this.ch_44.TabIndex = 44;
            this.ch_44.Text = "44";
            this.ch_44.UseVisualStyleBackColor = false;
            this.ch_44.Click += new System.EventHandler(this.ch_44_Click);
            // 
            // ch_43
            // 
            this.ch_43.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_43.Location = new System.Drawing.Point(207, 95);
            this.ch_43.Name = "ch_43";
            this.ch_43.Size = new System.Drawing.Size(35, 35);
            this.ch_43.TabIndex = 43;
            this.ch_43.Text = "43";
            this.ch_43.UseVisualStyleBackColor = false;
            this.ch_43.Click += new System.EventHandler(this.ch_43_Click);
            // 
            // ch_42
            // 
            this.ch_42.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_42.Location = new System.Drawing.Point(173, 95);
            this.ch_42.Name = "ch_42";
            this.ch_42.Size = new System.Drawing.Size(35, 35);
            this.ch_42.TabIndex = 42;
            this.ch_42.Text = "42";
            this.ch_42.UseVisualStyleBackColor = false;
            this.ch_42.Click += new System.EventHandler(this.ch_42_Click);
            // 
            // ch_41
            // 
            this.ch_41.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_41.Location = new System.Drawing.Point(104, 95);
            this.ch_41.Name = "ch_41";
            this.ch_41.Size = new System.Drawing.Size(35, 35);
            this.ch_41.TabIndex = 41;
            this.ch_41.Text = "41";
            this.ch_41.UseVisualStyleBackColor = false;
            this.ch_41.Click += new System.EventHandler(this.ch_41_Click);
            // 
            // ch_40
            // 
            this.ch_40.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_40.Location = new System.Drawing.Point(72, 95);
            this.ch_40.Name = "ch_40";
            this.ch_40.Size = new System.Drawing.Size(35, 35);
            this.ch_40.TabIndex = 40;
            this.ch_40.Text = "40";
            this.ch_40.UseVisualStyleBackColor = false;
            this.ch_40.Click += new System.EventHandler(this.ch_40_Click);
            // 
            // ch_39
            // 
            this.ch_39.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_39.Location = new System.Drawing.Point(38, 95);
            this.ch_39.Name = "ch_39";
            this.ch_39.Size = new System.Drawing.Size(35, 35);
            this.ch_39.TabIndex = 39;
            this.ch_39.Text = "39";
            this.ch_39.UseVisualStyleBackColor = false;
            this.ch_39.Click += new System.EventHandler(this.ch_39_Click);
            // 
            // ch_38
            // 
            this.ch_38.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_38.Location = new System.Drawing.Point(430, 65);
            this.ch_38.Name = "ch_38";
            this.ch_38.Size = new System.Drawing.Size(35, 35);
            this.ch_38.TabIndex = 38;
            this.ch_38.Text = "38";
            this.ch_38.UseVisualStyleBackColor = false;
            this.ch_38.Click += new System.EventHandler(this.ch_38_Click);
            // 
            // ch_37
            // 
            this.ch_37.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_37.Location = new System.Drawing.Point(400, 65);
            this.ch_37.Name = "ch_37";
            this.ch_37.Size = new System.Drawing.Size(35, 35);
            this.ch_37.TabIndex = 37;
            this.ch_37.Text = "37";
            this.ch_37.UseVisualStyleBackColor = false;
            this.ch_37.Click += new System.EventHandler(this.ch_37_Click);
            // 
            // ch_36
            // 
            this.ch_36.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_36.Location = new System.Drawing.Point(368, 65);
            this.ch_36.Name = "ch_36";
            this.ch_36.Size = new System.Drawing.Size(35, 35);
            this.ch_36.TabIndex = 36;
            this.ch_36.Text = "36";
            this.ch_36.UseVisualStyleBackColor = false;
            this.ch_36.Click += new System.EventHandler(this.ch_36_Click);
            // 
            // ch_35
            // 
            this.ch_35.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_35.Location = new System.Drawing.Point(334, 65);
            this.ch_35.Name = "ch_35";
            this.ch_35.Size = new System.Drawing.Size(35, 35);
            this.ch_35.TabIndex = 35;
            this.ch_35.Text = "35";
            this.ch_35.UseVisualStyleBackColor = false;
            this.ch_35.Click += new System.EventHandler(this.ch_35_Click);
            // 
            // ch_34
            // 
            this.ch_34.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_34.Location = new System.Drawing.Point(302, 65);
            this.ch_34.Name = "ch_34";
            this.ch_34.Size = new System.Drawing.Size(35, 35);
            this.ch_34.TabIndex = 34;
            this.ch_34.Text = "34";
            this.ch_34.UseVisualStyleBackColor = false;
            this.ch_34.Click += new System.EventHandler(this.ch_34_Click);
            // 
            // ch_33
            // 
            this.ch_33.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_33.Location = new System.Drawing.Point(270, 65);
            this.ch_33.Name = "ch_33";
            this.ch_33.Size = new System.Drawing.Size(35, 35);
            this.ch_33.TabIndex = 33;
            this.ch_33.Text = "33";
            this.ch_33.UseVisualStyleBackColor = false;
            this.ch_33.Click += new System.EventHandler(this.ch_33_Click);
            // 
            // ch_32
            // 
            this.ch_32.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_32.Location = new System.Drawing.Point(239, 65);
            this.ch_32.Name = "ch_32";
            this.ch_32.Size = new System.Drawing.Size(35, 35);
            this.ch_32.TabIndex = 32;
            this.ch_32.Text = "32";
            this.ch_32.UseVisualStyleBackColor = false;
            this.ch_32.Click += new System.EventHandler(this.ch_32_Click);
            // 
            // ch_31
            // 
            this.ch_31.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_31.Location = new System.Drawing.Point(207, 65);
            this.ch_31.Name = "ch_31";
            this.ch_31.Size = new System.Drawing.Size(35, 35);
            this.ch_31.TabIndex = 31;
            this.ch_31.Text = "31";
            this.ch_31.UseVisualStyleBackColor = false;
            this.ch_31.Click += new System.EventHandler(this.ch_31_Click);
            // 
            // ch_30
            // 
            this.ch_30.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_30.Location = new System.Drawing.Point(173, 65);
            this.ch_30.Name = "ch_30";
            this.ch_30.Size = new System.Drawing.Size(35, 35);
            this.ch_30.TabIndex = 30;
            this.ch_30.Text = "30";
            this.ch_30.UseVisualStyleBackColor = false;
            this.ch_30.Click += new System.EventHandler(this.ch_30_Click);
            // 
            // ch_29
            // 
            this.ch_29.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_29.Location = new System.Drawing.Point(136, 65);
            this.ch_29.Name = "ch_29";
            this.ch_29.Size = new System.Drawing.Size(40, 35);
            this.ch_29.TabIndex = 29;
            this.ch_29.Text = "29";
            this.ch_29.UseVisualStyleBackColor = false;
            this.ch_29.Click += new System.EventHandler(this.ch_29_Click);
            // 
            // ch_28
            // 
            this.ch_28.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_28.Location = new System.Drawing.Point(104, 65);
            this.ch_28.Name = "ch_28";
            this.ch_28.Size = new System.Drawing.Size(35, 35);
            this.ch_28.TabIndex = 28;
            this.ch_28.Text = "28";
            this.ch_28.UseVisualStyleBackColor = false;
            this.ch_28.Click += new System.EventHandler(this.ch_28_Click);
            // 
            // ch_27
            // 
            this.ch_27.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_27.Location = new System.Drawing.Point(72, 65);
            this.ch_27.Name = "ch_27";
            this.ch_27.Size = new System.Drawing.Size(35, 35);
            this.ch_27.TabIndex = 27;
            this.ch_27.Text = "27";
            this.ch_27.UseVisualStyleBackColor = false;
            this.ch_27.Click += new System.EventHandler(this.ch_27_Click);
            // 
            // ch_26
            // 
            this.ch_26.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_26.Location = new System.Drawing.Point(38, 65);
            this.ch_26.Name = "ch_26";
            this.ch_26.Size = new System.Drawing.Size(35, 35);
            this.ch_26.TabIndex = 26;
            this.ch_26.Text = "26";
            this.ch_26.UseVisualStyleBackColor = false;
            this.ch_26.Click += new System.EventHandler(this.ch_26_Click);
            // 
            // ch_25
            // 
            this.ch_25.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_25.Location = new System.Drawing.Point(5, 65);
            this.ch_25.Name = "ch_25";
            this.ch_25.Size = new System.Drawing.Size(35, 35);
            this.ch_25.TabIndex = 25;
            this.ch_25.Text = "25";
            this.ch_25.UseVisualStyleBackColor = false;
            this.ch_25.Click += new System.EventHandler(this.ch_25_Click);
            // 
            // ch_24
            // 
            this.ch_24.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_24.Location = new System.Drawing.Point(430, 35);
            this.ch_24.Name = "ch_24";
            this.ch_24.Size = new System.Drawing.Size(35, 35);
            this.ch_24.TabIndex = 24;
            this.ch_24.Text = "24";
            this.ch_24.UseVisualStyleBackColor = false;
            this.ch_24.Click += new System.EventHandler(this.ch_24_Click);
            // 
            // ch_23
            // 
            this.ch_23.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_23.Location = new System.Drawing.Point(400, 35);
            this.ch_23.Name = "ch_23";
            this.ch_23.Size = new System.Drawing.Size(35, 35);
            this.ch_23.TabIndex = 23;
            this.ch_23.Text = "23";
            this.ch_23.UseVisualStyleBackColor = false;
            this.ch_23.Click += new System.EventHandler(this.ch_23_Click);
            // 
            // ch_22
            // 
            this.ch_22.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_22.Location = new System.Drawing.Point(368, 35);
            this.ch_22.Name = "ch_22";
            this.ch_22.Size = new System.Drawing.Size(35, 35);
            this.ch_22.TabIndex = 22;
            this.ch_22.Text = "22";
            this.ch_22.UseVisualStyleBackColor = false;
            this.ch_22.Click += new System.EventHandler(this.ch_22_Click);
            // 
            // ch_21
            // 
            this.ch_21.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_21.Location = new System.Drawing.Point(334, 35);
            this.ch_21.Name = "ch_21";
            this.ch_21.Size = new System.Drawing.Size(35, 35);
            this.ch_21.TabIndex = 21;
            this.ch_21.Text = "21";
            this.ch_21.UseVisualStyleBackColor = false;
            this.ch_21.Click += new System.EventHandler(this.ch_21_Click);
            // 
            // ch_20
            // 
            this.ch_20.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_20.Location = new System.Drawing.Point(302, 35);
            this.ch_20.Name = "ch_20";
            this.ch_20.Size = new System.Drawing.Size(35, 35);
            this.ch_20.TabIndex = 20;
            this.ch_20.Text = "20";
            this.ch_20.UseVisualStyleBackColor = false;
            this.ch_20.Click += new System.EventHandler(this.ch_20_Click);
            // 
            // ch_19
            // 
            this.ch_19.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_19.Location = new System.Drawing.Point(270, 35);
            this.ch_19.Name = "ch_19";
            this.ch_19.Size = new System.Drawing.Size(35, 35);
            this.ch_19.TabIndex = 19;
            this.ch_19.Text = "19";
            this.ch_19.UseVisualStyleBackColor = false;
            this.ch_19.Click += new System.EventHandler(this.ch_19_Click);
            // 
            // ch_18
            // 
            this.ch_18.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_18.Location = new System.Drawing.Point(239, 35);
            this.ch_18.Name = "ch_18";
            this.ch_18.Size = new System.Drawing.Size(35, 35);
            this.ch_18.TabIndex = 18;
            this.ch_18.Text = "18";
            this.ch_18.UseVisualStyleBackColor = false;
            this.ch_18.Click += new System.EventHandler(this.ch_18_Click);
            // 
            // ch_17
            // 
            this.ch_17.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_17.Location = new System.Drawing.Point(207, 35);
            this.ch_17.Name = "ch_17";
            this.ch_17.Size = new System.Drawing.Size(35, 35);
            this.ch_17.TabIndex = 17;
            this.ch_17.Text = "17";
            this.ch_17.UseVisualStyleBackColor = false;
            this.ch_17.Click += new System.EventHandler(this.ch_17_Click);
            // 
            // ch_16
            // 
            this.ch_16.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_16.Location = new System.Drawing.Point(173, 35);
            this.ch_16.Name = "ch_16";
            this.ch_16.Size = new System.Drawing.Size(35, 35);
            this.ch_16.TabIndex = 16;
            this.ch_16.Text = "16";
            this.ch_16.UseVisualStyleBackColor = false;
            this.ch_16.Click += new System.EventHandler(this.ch_16_Click);
            // 
            // ch_15
            // 
            this.ch_15.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ch_15.Location = new System.Drawing.Point(136, 35);
            this.ch_15.Name = "ch_15";
            this.ch_15.Size = new System.Drawing.Size(40, 35);
            this.ch_15.TabIndex = 15;
            this.ch_15.Text = "15";
            this.ch_15.UseVisualStyleBackColor = false;
            this.ch_15.Click += new System.EventHandler(this.ch_15_Click);
            // 
            // ch_14
            // 
            this.ch_14.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_14.Location = new System.Drawing.Point(104, 35);
            this.ch_14.Name = "ch_14";
            this.ch_14.Size = new System.Drawing.Size(35, 35);
            this.ch_14.TabIndex = 14;
            this.ch_14.Text = "14";
            this.ch_14.UseVisualStyleBackColor = false;
            this.ch_14.Click += new System.EventHandler(this.ch_14_Click);
            // 
            // ch_13
            // 
            this.ch_13.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_13.Location = new System.Drawing.Point(72, 35);
            this.ch_13.Name = "ch_13";
            this.ch_13.Size = new System.Drawing.Size(35, 35);
            this.ch_13.TabIndex = 13;
            this.ch_13.Text = "13";
            this.ch_13.UseVisualStyleBackColor = false;
            this.ch_13.Click += new System.EventHandler(this.ch_13_Click);
            // 
            // ch_12
            // 
            this.ch_12.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_12.Location = new System.Drawing.Point(38, 35);
            this.ch_12.Name = "ch_12";
            this.ch_12.Size = new System.Drawing.Size(35, 35);
            this.ch_12.TabIndex = 12;
            this.ch_12.Text = "12";
            this.ch_12.UseVisualStyleBackColor = false;
            this.ch_12.Click += new System.EventHandler(this.ch_12_Click);
            // 
            // ch_11
            // 
            this.ch_11.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_11.Location = new System.Drawing.Point(5, 35);
            this.ch_11.Name = "ch_11";
            this.ch_11.Size = new System.Drawing.Size(35, 35);
            this.ch_11.TabIndex = 11;
            this.ch_11.Text = "11";
            this.ch_11.UseVisualStyleBackColor = false;
            this.ch_11.Click += new System.EventHandler(this.ch_11_Click);
            // 
            // ch_7
            // 
            this.ch_7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_7.Location = new System.Drawing.Point(270, 3);
            this.ch_7.Name = "ch_7";
            this.ch_7.Size = new System.Drawing.Size(35, 35);
            this.ch_7.TabIndex = 10;
            this.ch_7.Text = "7";
            this.ch_7.UseVisualStyleBackColor = false;
            this.ch_7.Click += new System.EventHandler(this.ch_7_Click);
            // 
            // ch_10
            // 
            this.ch_10.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_10.Location = new System.Drawing.Point(400, 3);
            this.ch_10.Name = "ch_10";
            this.ch_10.Size = new System.Drawing.Size(35, 35);
            this.ch_10.TabIndex = 9;
            this.ch_10.Text = "10";
            this.ch_10.UseVisualStyleBackColor = false;
            this.ch_10.Click += new System.EventHandler(this.ch_10_Click);
            // 
            // ch_9
            // 
            this.ch_9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_9.Location = new System.Drawing.Point(368, 3);
            this.ch_9.Name = "ch_9";
            this.ch_9.Size = new System.Drawing.Size(35, 35);
            this.ch_9.TabIndex = 8;
            this.ch_9.Text = "9";
            this.ch_9.UseVisualStyleBackColor = false;
            this.ch_9.Click += new System.EventHandler(this.ch_9_Click);
            // 
            // ch_8
            // 
            this.ch_8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_8.Location = new System.Drawing.Point(334, 3);
            this.ch_8.Name = "ch_8";
            this.ch_8.Size = new System.Drawing.Size(35, 35);
            this.ch_8.TabIndex = 7;
            this.ch_8.Text = "8";
            this.ch_8.UseVisualStyleBackColor = false;
            this.ch_8.Click += new System.EventHandler(this.ch_8_Click);
            // 
            // ch_6
            // 
            this.ch_6.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_6.Location = new System.Drawing.Point(239, 3);
            this.ch_6.Name = "ch_6";
            this.ch_6.Size = new System.Drawing.Size(35, 35);
            this.ch_6.TabIndex = 6;
            this.ch_6.Text = "6";
            this.ch_6.UseVisualStyleBackColor = false;
            this.ch_6.Click += new System.EventHandler(this.ch_6_Click);
            // 
            // ch_5
            // 
            this.ch_5.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_5.Location = new System.Drawing.Point(207, 3);
            this.ch_5.Name = "ch_5";
            this.ch_5.Size = new System.Drawing.Size(35, 35);
            this.ch_5.TabIndex = 5;
            this.ch_5.Text = "5";
            this.ch_5.UseVisualStyleBackColor = false;
            this.ch_5.Click += new System.EventHandler(this.ch_5_Click);
            // 
            // ch_4
            // 
            this.ch_4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_4.Location = new System.Drawing.Point(173, 3);
            this.ch_4.Name = "ch_4";
            this.ch_4.Size = new System.Drawing.Size(35, 35);
            this.ch_4.TabIndex = 4;
            this.ch_4.Text = "4";
            this.ch_4.UseVisualStyleBackColor = false;
            this.ch_4.Click += new System.EventHandler(this.ch_4_Click);
            // 
            // ch_3
            // 
            this.ch_3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_3.Location = new System.Drawing.Point(104, 3);
            this.ch_3.Name = "ch_3";
            this.ch_3.Size = new System.Drawing.Size(35, 35);
            this.ch_3.TabIndex = 3;
            this.ch_3.Text = "3";
            this.ch_3.UseVisualStyleBackColor = false;
            this.ch_3.Click += new System.EventHandler(this.ch_3_Click);
            // 
            // ch_2
            // 
            this.ch_2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ch_2.Location = new System.Drawing.Point(72, 3);
            this.ch_2.Name = "ch_2";
            this.ch_2.Size = new System.Drawing.Size(35, 35);
            this.ch_2.TabIndex = 2;
            this.ch_2.Text = "2";
            this.ch_2.UseVisualStyleBackColor = false;
            this.ch_2.Click += new System.EventHandler(this.ch_2_Click);
            // 
            // ch_1
            // 
            this.ch_1.BackColor = System.Drawing.SystemColors.Highlight;
            this.ch_1.Location = new System.Drawing.Point(38, 3);
            this.ch_1.Name = "ch_1";
            this.ch_1.Size = new System.Drawing.Size(35, 35);
            this.ch_1.TabIndex = 1;
            this.ch_1.Text = "1";
            this.ch_1.UseVisualStyleBackColor = false;
            this.ch_1.Click += new System.EventHandler(this.ch_1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 26);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(837, 673);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Анализ групп сигналов";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // DataBaseName
            // 
            this.DataBaseName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.DataBaseName.FormattingEnabled = true;
            this.DataBaseName.Location = new System.Drawing.Point(462, 32);
            this.DataBaseName.Name = "DataBaseName";
            this.DataBaseName.Size = new System.Drawing.Size(164, 26);
            this.DataBaseName.TabIndex = 9;
            this.DataBaseName.Text = "DataBase_1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(840, 749);
            this.Controls.Add(this.DataBaseName);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.createDataBase_button);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.25F);
            this.ImeMode = System.Windows.Forms.ImeMode.Disable;
            this.Name = "Form1";
            this.Text = "Программа обработки данных гидролокационной станции";
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button createDataBase_button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button ch_45;
        private System.Windows.Forms.Button ch_48;
        private System.Windows.Forms.Button ch_47;
        private System.Windows.Forms.Button ch_46;
        private System.Windows.Forms.Button ch_44;
        private System.Windows.Forms.Button ch_43;
        private System.Windows.Forms.Button ch_42;
        private System.Windows.Forms.Button ch_41;
        private System.Windows.Forms.Button ch_40;
        private System.Windows.Forms.Button ch_39;
        private System.Windows.Forms.Button ch_38;
        private System.Windows.Forms.Button ch_37;
        private System.Windows.Forms.Button ch_36;
        private System.Windows.Forms.Button ch_35;
        private System.Windows.Forms.Button ch_34;
        private System.Windows.Forms.Button ch_33;
        private System.Windows.Forms.Button ch_32;
        private System.Windows.Forms.Button ch_31;
        private System.Windows.Forms.Button ch_30;
        private System.Windows.Forms.Button ch_29;
        private System.Windows.Forms.Button ch_28;
        private System.Windows.Forms.Button ch_27;
        private System.Windows.Forms.Button ch_26;
        private System.Windows.Forms.Button ch_25;
        private System.Windows.Forms.Button ch_24;
        private System.Windows.Forms.Button ch_23;
        private System.Windows.Forms.Button ch_22;
        private System.Windows.Forms.Button ch_21;
        private System.Windows.Forms.Button ch_20;
        private System.Windows.Forms.Button ch_19;
        private System.Windows.Forms.Button ch_18;
        private System.Windows.Forms.Button ch_17;
        private System.Windows.Forms.Button ch_16;
        private System.Windows.Forms.Button ch_15;
        private System.Windows.Forms.Button ch_14;
        private System.Windows.Forms.Button ch_13;
        private System.Windows.Forms.Button ch_12;
        private System.Windows.Forms.Button ch_11;
        private System.Windows.Forms.Button ch_7;
        private System.Windows.Forms.Button ch_10;
        private System.Windows.Forms.Button ch_9;
        private System.Windows.Forms.Button ch_8;
        private System.Windows.Forms.Button ch_6;
        private System.Windows.Forms.Button ch_5;
        private System.Windows.Forms.Button ch_4;
        private System.Windows.Forms.Button ch_3;
        private System.Windows.Forms.Button ch_2;
        private System.Windows.Forms.Button ch_1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ComboBox DataBaseName;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button buildGraph_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox endFFTtextBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox beginFFTtextBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button buildFFTbtn;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.TextBox endRangeTextBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox beginRangeTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
    }
}

